import './App.css';

import React, { Component } from "react"

class App extends React.Component {
  constructor() {
    super();
    this.state = { counter: 0 } //mutable
    this.handleIncrement = this.handleIncrement.bind(this)
    // this.handleIncrement = this.handleIncrement.bind(this)
    this.handleDecrement = this.handleDecrement.bind(this)

  }
  handleIncrement() {
    this.setState({ counter: this.state.counter + 1 })
  }
  handleDecrement() {
    this.setState({ counter: this.state.counter - 1 }); //setState
  }
  render() {
    return (
      <div>
        <h1>Counter</h1>
        <label>{this.state.counter}</label>
        <button onClick={this.handleIncrement}>++</button>
        <button onClick={this.handleDecrement}>--</button>


      </div>
    );
  }
}
export default App;


