import React, { Component } from "react"

class App1 extends React.Component {
    render() {
        return (
            <div>
                <h1>Mobile</h1>
                <Mobileprice />
                <MobileModel model="Samsung" />
            </div>
        );
    }
}
export default App1

class Mobileprice extends React.Component {
    render() {
        return (
            <div>
                <h1>Mobile price is 100rs</h1>
            </div>
        );
    }
}

class MobileModel extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div>
                <h1>the model is {this.props.model}  </h1>
            </div>
        );
    }
}