import React, { Component } from "react"

class App2 extends React.Component {
    constructor() {
        super();
        this.state = { num1: '', num2: '' };
        this.handleChange = this.handleChange.bind(this);



    }
    handleChange(event) {
        this.setState({ [event.target.name]: event.target.value });
    }

    render() {
        return (
            <div>
                <form>
                    <label>
                        Number1:
                        <input type="number" name="num1" value={this.state.num1} onChange={this.handleChange} />
                        Number2:
                        <input type="number" name="num2" value={this.state.num2} onChange={this.handleChange} />
                    </label>
                </form>
                <Calculator num1={Number(this.state.num1)} num2={Number(this.state.num2)} />
            </div>


        );
    }
}
export default App2



class Calculator extends React.Component {
    constructor(props) {
        super(props)
        this.calSum = this.calSum.bind(this)
        this.calDif = this.calDif.bind(this)
        this.calPro = this.calPro.bind(this)
        this.calDiv = this.calDiv.bind(this)
        this.state = { result: '' }

    }
    calSum() {
        this.setState({ result: this.props.num1 + this.props.num2 })
    }
    calDif() {
        this.setState({ result: this.props.num1 - this.props.num2 })
    }
    calPro() {
        this.setState({ result: this.props.num1 * this.props.num2 })
    }
    calDiv() {
        this.setState({ result: this.props.num1 / this.props.num2 })

    }

    render() {
        return (
            <div>
                <button onClick={this.calSum}>Addd</button>
                <button onClick={this.calDif}>Diff</button>
                <button onClick={this.calPro}>Prodd</button>
                <button onClick={this.calDiv}>Divv</button>
                <h3>Result:{this.state.result}</h3>
            </div>
        );
    }
}