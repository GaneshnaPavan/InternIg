package codingtestsolution;



public class Account {
    private Integer accNumber;
    private String custName;
    private AccountType type;
    private Float balance;

    public Account(Integer accNumber, String custName, AccountType type, float balance) throws AccountException {
        if (balance < 0) {
            throw new AccountException("Balance cannot be negative");
        }
        if (type == AccountType.SAVINGS && balance < 1000) {
            throw new AccountException("Initial balance for savings account should be at least Rs. 1000");
        }
        if (type == AccountType.CURRENT && balance < 5000) {
            throw new AccountException("Initial balance for current account should be at least Rs. 5000");
        }
        this.accNumber = accNumber;
        this.custName = custName;
        this.type = type;
        this.balance = balance;
    }

    
    public Integer getAccNumber() {
        return accNumber;
    }

    public void setAccNumber(Integer accNumber) {
        this.accNumber = accNumber;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public AccountType getType() {
        return type;
    }

    public void setType(AccountType type) {
        this.type = type;
    }

    public Float getBalance() {
        return balance;
    }

    public void setBalance(Float balance) {
        this.balance = balance;
    }
}

enum AccountType {
    SAVINGS, CURRENT
}
