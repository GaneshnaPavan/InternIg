package codingtestsolution;

import java.util.ArrayList;
import java.util.List;



public class AccountService {
    private List<Account> accountList = new ArrayList<>();

    public boolean isValidAccount(int accNumber) {
        for (Account account : accountList) {
            if (account.getAccNumber().equals(accNumber)) {
                return true;
            }
        }
        return false;
    }

    public void deposit(int accNumber, float amt) throws AccountException {
        Account account = getAccountByAccNumber(accNumber);
        if (amt < 0) {
            throw new AccountException("Invalid amount. Amount cannot be negative");
        }
        account.setBalance(account.getBalance() + amt);
    }

    public void withdraw(int accNumber, float amt) throws AccountException {
        Account account = getAccountByAccNumber(accNumber);
        if (amt < 500) {
            throw new AccountException("Minimum amount to withdraw is Rs. 500");
        }
        if (account.getBalance() - amt < 0) {
            throw new AccountException("Insufficient balance");
        }
        if (account.getType() == AccountType.SAVINGS && account.getBalance() - amt < 1000) {
            throw new AccountException("Savings account must maintain a minimum balance of Rs. 1000");
        }
        if (account.getType() == AccountType.CURRENT && account.getBalance() - amt < 5000) {
            throw new AccountException("Current account must maintain a minimum balance of Rs. 5000");
        }
        account.setBalance(account.getBalance() - amt);
    }

    public float getBalance(int accNumber) throws AccountException {
        Account account = getAccountByAccNumber(accNumber);
        return account.getBalance();
    }

    private Account getAccountByAccNumber(int accNumber) throws AccountException {
        for (Account account : accountList) {
            if (account.getAccNumber().equals(accNumber)) {
                return account;
            }
        }
        throw new AccountException("Account not found");
    }

    
    public void addAccount(Account account) throws AccountException {
   
        if (isValidAccount(account.getAccNumber())) {
            throw new AccountException("Duplicate account number: " + account.getAccNumber());
        }
       
        accountList.add(account);
    }

}

