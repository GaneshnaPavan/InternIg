package codingtestsolution;



public class AccountTest {
    public static void main(String[] args) {
        AccountService accountService = new AccountService();
        try {
            Account acc1 = new Account(101, "John Doe", AccountType.SAVINGS, 1000);
            Account acc2 = new Account(103, "Jane Doe", AccountType.CURRENT, 7000);

            accountService.addAccount(acc1);
            accountService.addAccount(acc2);

            accountService.deposit(101, 1000);
            System.out.println("Balance after deposit: " + accountService.getBalance(101));

            accountService.withdraw(101, 500);
            System.out.println("Balance after withdrawal: " + accountService.getBalance(101));
        } catch (AccountException e) {
            e.printStackTrace();
        }
    }
}
