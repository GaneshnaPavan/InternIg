package cm.ms.productclient;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.retry.annotation.Retry;

@RestController
public class ClientController {

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    DiscoveryClient discoveryClient;

    // --------- Method 1: Call /prod/{id} ----------------
    @GetMapping("/addToCart/{id}") // example: http://localhost:8083/addToCart/2
    @Retry(name = "producer", fallbackMethod = "sendDummyData")
    public String addToCart(@PathVariable Integer id) {
        List<ServiceInstance> siList = discoveryClient.getInstances("PRODUCTSERVICE");
        if (siList == null || siList.isEmpty()) {
            throw new RuntimeException("PRODUCTSERVICE not available");
        }
        ServiceInstance si = siList.get(0);
        String url = si.getUri() + "/prod/" + id;
        String response = restTemplate.getForObject(url, String.class);
        System.out.println("Response from /prod/{id} = " + response);
        return response;
    }

    // --------- Method 2: Call /recommendations ---------
    @GetMapping("/recommendations") // example: http://localhost:8083/recommendations
    @Retry(name = "producer", fallbackMethod = "sendDummyData")
    public String getRecommendations() {
        List<ServiceInstance> siList = discoveryClient.getInstances("PRODUCTSERVICE");
        if (siList == null || siList.isEmpty()) {
            throw new RuntimeException("PRODUCTSERVICE not available");
        }
        ServiceInstance si = siList.get(0);
        String url = si.getUri() + "/recommendations";
        String response = restTemplate.getForObject(url, String.class);
        System.out.println("Response from /recommendations = " + response);
        return response;
    }

    // --------- Fallback Method ---------
    public String sendDummyData(Exception e) {
        return "Product Service is unavailable, please try again later.";
    }
}
