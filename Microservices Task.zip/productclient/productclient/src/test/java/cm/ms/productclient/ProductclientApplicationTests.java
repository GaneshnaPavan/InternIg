package cm.ms.productclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
