package cm.ms.productservice;

public class productModel {
	Integer prodId;
	String prodName;
	Double prodPrice;
	Double prodQuantity;
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public Double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(Double prodPrice) {
		this.prodPrice = prodPrice;
	}
	public Double getProdQuantity() {
		return prodQuantity;
	}
	public void setProdQuantity(Double prodQuantity) {
		this.prodQuantity = prodQuantity;
	}
	public productModel(Integer prodId, String prodName, Double prodPrice, Double prodQuantity) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.prodPrice = prodPrice;
		this.prodQuantity = prodQuantity;
	}
	public productModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "productModel [prodId=" + prodId + ", prodName=" + prodName + ", prodPrice=" + prodPrice
				+ ", prodQuantity=" + prodQuantity + "]";
	}



}
