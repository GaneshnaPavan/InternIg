package cm.ms.productservice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableDiscoveryClient
public class productController {

	static List<productModel> prodList=new ArrayList<>();
	static {
		prodList.add(new productModel(1,"aa",900.0,800.0));
		prodList.add(new productModel(2,"bb",6000.0,600.0));
		prodList.add(new productModel(3,"cc",700.0,900.0));
		prodList.add(new productModel(4,"dd",8000.0,100.0));
	}
	static List<productModel> cartList=new ArrayList<>();

	@GetMapping("prod/{id}")
	public String add(@PathVariable Integer id) {
		productModel product=prodList.stream().filter(x->x.getProdId()==id).findFirst().orElse(null);
		if(product.getProdPrice()<1000.0) {
		cartList.add(product);
		return "Added to cart";
		}
		return "Not added";
	}

	@GetMapping("/recommendations")
	public List<productModel> getRecommendations(){
        double max = cartList.stream().mapToDouble(productModel::getProdPrice).max().orElse(0);

		return prodList.stream().filter(x->x.getProdPrice()<=max).toList();
	}

}
