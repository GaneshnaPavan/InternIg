package ui;

import java.util.Scanner;

import model.Scholar;
import service.ScholarService;
import service.ScholarServiceImpl;



public class ScholarUi {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ScholarService scholarService=new ScholarServiceImpl();
		Scanner sc=new Scanner(System.in);
		
		boolean flag=true;
		while(flag) {
			System.out.println("Enter your choice");
			System.out.println("1.List all scholars");
			System.out.println("2.get one scholar ");
			System.out.println("3.update scholar");
			System.out.println("4.delete scholar");
			System.out.println("5.add scholar");
			System.out.println("6.Exit");

			
			int n=sc.nextInt();
			switch(n) {
			case 1:
				System.out.println("=====List of all scholars=====");
				scholarService.ListAllScholars().forEach(x->System.out.println(x));
				break;
			case 2:
				System.out.println("Enter the id");
				int i=sc.nextInt();
				System.out.println(scholarService.GetOneScholar(i));

				break;
			case 3:
				System.out.println("Enter the id");
				int id=sc.nextInt();
				System.out.println("Enter the email to be updated");
				String email=sc.next();
				Scholar original=new Scholar();
				Scholar scholar=new Scholar();
				scholarService.GetOneScholar(id);
				original=scholarService.GetOneScholar(id);
				scholar.setScholarId(id);
				scholar.setName(original.getName());
				scholar.setEmail(email);
				scholar.setMobile(original.getMobile());
				scholarService.UpdateScolarEmail(id, scholar);
				System.out.println("Updatedd....");
				break;
			case 4:
				System.out.println("Enter the id of the scholar to be deleted");
				int idd=sc.nextInt();
				scholarService.DeleteScholarById(idd);
				System.out.println("Deleted");
				
				break;
			case 5:
				System.out.println("Enter the value of the scholars-id,name,email,mobile number");
				int sid=sc.nextInt();
				String sname=sc.next();
				String semail=sc.next();
				String smobile=sc.next();
				Scholar sch=new Scholar();
				sch.setScholarId(sid);
				sch.setName(sname);
				sch.setEmail(semail);
				sch.setMobile(smobile);
				scholarService.AddScholar(sch);
				System.out.println("Addedd");
				break;
			case 6:
				System.out.println("Exiting....");
				flag=false;
				break;
			}
			
			}
			
		
		
		
		
	}
	

}
