package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import dao.ScholarDao;
import dao.ScholarDaoImpl;
import model.Scholar;
import util.DbUtil;

public class ScholarServiceImpl implements ScholarService {
	ScholarDao scholarDao;
	public List<Scholar> ListAllScholars() throws Exception{
		scholarDao=new ScholarDaoImpl();
		return scholarDao.ListAllScholars();
	}
	public Scholar GetOneScholar(Integer scholarId) throws Exception{

		scholarDao=new ScholarDaoImpl();
		return scholarDao.GetOneScholar(scholarId);

	}
	public void UpdateScolarEmail(Integer scholarid,Scholar scholar) throws Exception{
		scholarDao=new ScholarDaoImpl();
		scholarDao.UpdateScolarEmail(scholarid, scholar);

	}
	public void DeleteScholarById(Integer scholarId) throws Exception{

		scholarDao=new ScholarDaoImpl();
		scholarDao.DeleteScholarById(scholarId);
	}
	public void AddScholar(Scholar scholar) throws Exception{

		scholarDao=new ScholarDaoImpl();
		scholarDao.AddScholar(scholar);
	}

}
