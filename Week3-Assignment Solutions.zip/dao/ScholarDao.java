package dao;

import java.util.List;

import model.Scholar;

public interface ScholarDao {
	
	public List<Scholar> ListAllScholars() throws Exception;
	public Scholar GetOneScholar(Integer scholarId) throws Exception;
	public void UpdateScolarEmail(Integer scholarid,Scholar scholar) throws Exception;
	public void DeleteScholarById(Integer scholarId) throws Exception;
	public void AddScholar(Scholar scholar) throws Exception;

}

