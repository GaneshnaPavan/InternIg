package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Scholar;
import util.DbUtil;

public class ScholarDaoImpl implements ScholarDao {
	public List<Scholar> ListAllScholars() throws Exception{
		ArrayList <Scholar> scholarList=new ArrayList<>();
		Connection con=DbUtil.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from scholar");
		while(rs.next()) {
			Scholar scholar=new Scholar();
			scholar.setScholarId(rs.getInt(1));
			scholar.setName(rs.getString(2));
			scholar.setEmail(rs.getString(3));
			scholar.setMobile(rs.getString(4));
			scholarList.add(scholar);
		}
		return scholarList;
	}
	public Scholar GetOneScholar(Integer scholarId) throws Exception{
		 Connection con=DbUtil.getConnection();
		 PreparedStatement pst=con.prepareStatement("select * from scholar where scholarId=?");
		 pst.setInt(1, scholarId);
		 ResultSet rs=pst.executeQuery();
		 Scholar scholar=new Scholar();
		 while(rs.next()) {
				scholar.setScholarId(rs.getInt(1));
				scholar.setName(rs.getString(2));
				scholar.setEmail(rs.getString(3));
				scholar.setMobile(rs.getString(4));
			}
		 return scholar;

	}
	public void UpdateScolarEmail(Integer scholarid,Scholar scholar) throws Exception{
		Connection con=DbUtil.getConnection();
		 PreparedStatement pst=con.prepareStatement("update scholar set email=? where scholarId=?");
		 pst.setString(1,scholar.getEmail());
		 pst.setInt(2, scholarid);
		 pst.executeUpdate();
	}
	public void DeleteScholarById(Integer scholarId) throws Exception{
		Connection con=DbUtil.getConnection();
		 PreparedStatement pst=con.prepareStatement("delete from scholar where scholarId=?");
		 pst.setInt(1, scholarId);
		 pst.executeUpdate();
	}
	public void AddScholar(Scholar scholar) throws Exception{
		 Connection con=DbUtil.getConnection();
		  PreparedStatement pst=con.prepareStatement("insert into scholar values (?,?,?,?)");
		  pst.setInt(1,scholar.getScholarId());
		  pst.setString(2, scholar.getName());
		  pst.setString(3, scholar.getEmail());
		  pst.setString(4,scholar.getMobile());
		  pst.execute();
	}


}
