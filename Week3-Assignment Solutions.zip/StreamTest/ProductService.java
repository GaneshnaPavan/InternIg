package StreamTest;



import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;



public class ProductService {
	List<Product> proList = new ArrayList<>();

	
	public ProductService(){
	
	
		
		proList.add(new Product(1, "milk", "toned", 30.0, 100.00, LocalDate.of(2025, 12, 31),new Supplier(11,"Abc")));
		proList.add(new Product(2, "biscuits", "white",20.0, 120.00, LocalDate.of(2025,3, 14),new Supplier(22,"Efg")));
		proList.add(new Product(3, "chocolates", "milk",100.00, 1000.00, LocalDate.of(2025, 10, 30),new Supplier(33,"hij")));
		proList.add(new Product(4, "bread", "white",20.00, 300.00, LocalDate.of(2025, 9, 15),new Supplier(44,"klm")));
		proList.add(new Product(5, "drinks", "cococola",20.00, 2000.00, LocalDate.of(2024, 1, 25),new Supplier(55,"klm")));
		
}
	public static void main(String[] args) {
		ProductService pros=new ProductService();
		System.out.println("Highest price");
		Comparator<Product> comp=(a,b)->b.price.compareTo(a.price);
		pros.proList.stream().sorted(comp).limit(1).forEach(x->System.out.println(x));
		
		System.out.println("lowesst price");
		Comparator<Product> comp1=(a,b)->a.price.compareTo(b.price);
		pros.proList.stream().sorted(comp1).limit(1).forEach(x->System.out.println(x));
		
		System.out.println("Already Expired");
		pros.proList.stream().filter(x->x.expiryDate.isBefore(LocalDate.now())).forEach(x->System.out.println(x));
		
		System.out.println("Expiry date 10 days");
		pros.proList.stream().filter(x->x.expiryDate.minusDays(10).isEqual(LocalDate.now())).forEach(x->System.out.println(x));
		
		System.out.println("Group by type");
		Map<String,Long> map1=pros.proList.stream().collect(Collectors.groupingBy(Product::getType,Collectors.counting()));
		map1.forEach((a,b)->System.out.println(a+b));
		
		System.out.println("Count by supplier name");
		Map<String, Long> map2 = pros.proList.stream().collect(Collectors.groupingBy(product -> product.getSupplier().getSname(), Collectors.counting()));		
		map2.forEach((a,b)->System.out.println(a+b));

		
		
		
	}
}


