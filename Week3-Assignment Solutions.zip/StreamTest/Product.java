package StreamTest;



import java.time.LocalDate;
 class Supplier {
	Integer id;

	String sname;

	public Supplier(Integer id, String sname) {
		super();
		this.id = id;
		this.sname = sname;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}
	
	
}


public class Product {
	Integer id;

	String name;

	String type; 

	Double qty;

	Double price;

	LocalDate expiryDate;
	
	Supplier supplier;

	public Product(Integer id, String name, String type, Double qty, Double price, LocalDate expiryDate,
			Supplier supplier) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.qty = qty;
		this.price = price;
		this.expiryDate = expiryDate;
		this.supplier = supplier;
	}
	

	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public Supplier getSupplier() {
		return supplier;
	}


	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}


	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", type=" + type + ", qty=" + qty + ", price=" + price
				+ ", expiryDate=" + expiryDate + ", supplier=" + supplier + "]";
	}
	
	

	
	
	
	

	
	
}
