package com.ig.justForTest;

import java.util.*;

class AdvisorThread extends Thread{
	String [] advices;
	Random random;
	public AdvisorThread(String[] advices, Random random) {
		this.advices = advices;
		this.random = random;
	}
	public void run() {
		System.out.println(advices[random.nextInt(3)]);
	}
	
}

public class Advisor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r =new Random();
		String arr[]=new String[3];
		arr[0]="Never begin to stop and never stop to begin.";
		arr[1]="Only destination isn’t important, one should enjoy the journey";
		arr[2]="impossible itself says ‘i m possible’";
		
		AdvisorThread thr=new AdvisorThread(arr,r);
		thr.start();
		AdvisorThread thr1=new AdvisorThread(arr,r);
		thr1.start();
		}

}
