package com.ig.justForTest;


class ConfRoom {
	boolean available=true;
	synchronized boolean availability() {
		
		return available;
	}
	synchronized void bookroom() {
		available = false;
		System.out.println("The room is booked");
	}
}

class Room extends Thread{
	ConfRoom conf;
	Room(ConfRoom conf)
	{
		this.conf=conf;
		this.start();
	}
	public void run() {
		if(conf.availability()) {
			
			conf.bookroom();
		}
		else {
			System.out.println("not available room");
		}
		
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConfRoom conf=new ConfRoom();
		Room r1=new Room(conf);
		Room r2=new Room(conf);
		Room r3=new Room(conf);

		

	}
	}


