import React, { useState, useEffect } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

const withLogging = (X) => {
    return ({ data }) => {
        const [tableData, setTableData] = useState([]);


        useEffect(() => {
            console.log(`Component ${X.name}m mounted`);
            setTableData(data); // Set tableData with the data prop

            return () => console.log(`Component ${X.name} unmounted`)
        }, [data]);
        return (
            <div className="container mt-4">
                <table className="table table-bordered table-striped">
                    <thead className="thead-dark">
                        <tr>
                            {tableData.length > 0 && Object.keys(tableData[0]).map((key, index) => (
                                <th key={index}>{key.toUpperCase()}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        <X data={tableData} />
                    </tbody>
                </table>
            </div>
        );
    };
};
export const HOCList = () => {
    const products = [
        { id: 1, name: "Laptop", price: "$1000" },
        { id: 2, name: "Phone", price: "$500" },
    ];
    const emp = [
        { id: 1, name: "janaki", salary: "1000" },
        { id: 2, name: "pavan", salary: "500" },
    ];
    return (
        <div>
            <h2>Product List</h2>
            <ProductTable data={products} />

            <h2>Employee List</h2>
            <EmployeeTable data={emp} />
        </div>

    )
}
const ProductList = ({ data }) => {
    return (
        <>
            {data.map((prod) => (
                <tr key={prod.id}>
                    <td>{prod.id}</td>
                    <td>{prod.name}</td>
                    <td>{prod.price}</td>
                </tr>
            ))}
        </>
    );
};

const EmployeeList = ({ data }) => {
    return (
        <>
            {data.map((emp) => (
                <tr key={emp.id}>
                    <td>{emp.id}</td>
                    <td>{emp.name}</td>
                    <td>{emp.salary}</td>
                </tr>
            ))}
        </>
    );
};
const ProductTable = withLogging(ProductList);
const EmployeeTable = withLogging(EmployeeList);