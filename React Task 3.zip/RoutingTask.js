import { Routes, Route, Outlet, Link } from "react-router-dom";
import React, { useState } from "react";
export default function RTask() {
    return (
        <>
            <Routes>
                <Route path="/" element={<Layout />}>
                    <Route index element={<Home />}></Route>
                    <Route path="login" element={<Login />}></Route>
                    <Route path="signup" element={<Signup />}></Route>
                </Route>
            </Routes>
        </>
    )
}

function Layout() {
    return (
        <>
            <ul>
                <li>
                    <Link to="/">Home</Link>
                </li>
                <li>
                    <Link to="/login">Login</Link>
                </li>
                <li>
                    <Link to="/signup">Sign up</Link>
                </li>

            </ul>
            <hr />
            <Outlet />
        </>
    )
}

function Home() {
    return (
        <>
            <h1>HOME PAGE</h1>
        </>
    )
}

function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const handleSubmit = (event) => {
        event.preventDefault();
    };
    const handleChange = (event) => {
        const { name, value } = event.target;
        if (name === 'username') {
            setUsername(value);
        } else if (name === 'password') {
            setPassword(value);
        }
    }

    return (
        <>
            <h1>Login</h1>
            <form onSubmit={handleSubmit}>
                <label>Username</label>
                <input type="text" name="username" value={username} onChange={handleChange} /> <br />
                <label>Password</label>
                <input type="password" name="password" value={password} onChange={handleChange} /> <br />
                <button type="submit">Login</button>
            </form>
        </>

    )
}

function Signup() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const handleSubmit = (event) => {
        event.preventDefault();
    };
    const handleChange = (event) => {
        const { name, value } = event.target;
        if (name === 'username') {
            setUsername(value);
        } else if (name === 'password') {
            setPassword(value);
        }
    }

    return (
        <>
            <h1>Sign in</h1>
            <form onSubmit={handleSubmit}>
                <label>Username</label>
                <input type="text" name="username" value={username} onChange={handleChange} /> <br />
                <label> Create Password</label>
                <input type="password" name="password" value={password} onChange={handleChange} /> <br />
                <button type="submit">Login</button>
            </form>
        </>

    )
}
