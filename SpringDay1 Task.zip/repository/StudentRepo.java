package repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import model.Student;

@Component
public class StudentRepo {

	static List<Student> slist=new ArrayList<>();
	static {
		slist.add(new Student(1,"AA"));
		slist.add(new Student(2,"BB"));
		slist.add(new Student(3,"CC"));
		slist.add(new Student(4,"DD"));
		slist.add(new Student(5,"DD"));
	}
	
	public void addStudent (Student student) {
		slist.add(student);
	}
	
	public void updateStudent(Integer id,String name) {
		for(Student student:slist) {
			if(student.getId()==id) {
				student.setName(name);
			}
		}
	}
	public void deleteStudent(Integer id) {
	    slist.removeIf(student -> student.getId().equals(id));

	}
	public List<Student> listAll() {
		return slist;
	}
	public Student list1Student(Integer id) {
		Student s1=new Student();
		for(Student student :slist) {
			if(student.getId()==id) {
				s1.setId(student.getId());
				s1.setName(student.getName());
			}
		}
		return s1;
	}
	

}
