package test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import model.Student;
import service.StudentService;

public class StudentTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AutoWiringConfig.class);
		StudentService studentService=(StudentService)context.getBean(StudentService.class);
		
		Student stu=new Student(100,"FF");
		studentService.addStudent(stu);
		
		System.out.println("Listt");
		List<Student> ls=studentService.listAll();
		ls.stream().forEach(x->System.out.println(x));
		
		System.out.println("getting single product");
		System.out.println(studentService.list1Student(2));
		
		studentService.deleteStudent(1);
		System.out.println("Listt");
		List<Student> ls1=studentService.listAll();
		ls1.stream().forEach(x->System.out.println(x));
		
		studentService.updateStudent(2, "Pavan");
		System.out.println("Listt");
		List<Student> ls2=studentService.listAll();
		ls2.stream().forEach(x->System.out.println(x));
	}

}
