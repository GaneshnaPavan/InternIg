package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import model.Student;
import repository.StudentRepo;

@Component
public class StudentService {
	@Autowired
	StudentRepo studentRepo;
	
	
	public void addStudent (Student student) {
		studentRepo.addStudent(student);
	}
	public void updateStudent(Integer id,String name) {
		studentRepo.updateStudent(id, name);
	}
	public void deleteStudent(Integer id) {
		studentRepo.deleteStudent(id);
	}
	public List<Student> listAll() {
		return studentRepo.listAll();
	}
	public Student list1Student(Integer id) {
		return studentRepo.list1Student(id);
	}


}
