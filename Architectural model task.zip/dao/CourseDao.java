package dao;

import java.sql.SQLException;
import java.util.List;

import exception.MyException;
import model.Course;

public interface CourseDao {
	public void addCourse(Course course) throws Exception;
	public List<Course> listAllCourses() throws Exception;
	public List<Course> getById(int id) throws MyException, SQLException,Exception;
	public List<Course> getByName(String name) throws MyException,SQLException,Exception;
	public void deleteCourseById(int id) throws MyException,SQLException,Exception;

}