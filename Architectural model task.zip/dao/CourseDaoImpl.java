package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import exception.MyException;
import model.Course;
import util.DbUtil;

public class CourseDaoImpl implements CourseDao{
	public void addCourse(Course course) throws Exception{
		Connection con=DbUtil.getConnection();
		PreparedStatement pst=con.prepareStatement("insert into course values(?,?)");
		pst.setInt(1,course.getCid());
		pst.setString(2, course.getCname());
		pst.execute();
		
	}
	public List<Course> listAllCourses() throws Exception{
		ArrayList<Course> courseList=new ArrayList<>();
		Connection con=DbUtil.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from course");
		while(rs.next()) {
			Course course=new Course();
			course.setCid(rs.getInt(1));
			course.setCname(rs.getString(2));
			courseList.add(course);
		}
		return courseList;
		
		
	}
	public List<Course> getById(int id) throws MyException, SQLException,Exception{
		ArrayList<Course> courseList=new ArrayList<>();
		Connection con=DbUtil.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from course");
		while(rs.next()) {
			Course course=new Course();
			course.setCid(rs.getInt(1));
			course.setCname(rs.getString(2));
			courseList.add(course);
		}
		if(courseList.stream().filter(x->x.getCid()==id).collect(Collectors.toList()).isEmpty()) {
			throw new MyException("There is no id at all!!!");
		}
		return courseList.stream().filter(x->x.getCid()==id).collect(Collectors.toList());
		
	}
	public List<Course> getByName(String name) throws MyException,SQLException,Exception{
		ArrayList<Course> courseList=new ArrayList<>();
		Connection con=DbUtil.getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from course");
		while(rs.next()) {
			Course course=new Course();
			course.setCid(rs.getInt(1));
			course.setCname(rs.getString(2));
			courseList.add(course);
		}
		if(courseList.stream().filter(x->x.getCname().equals(name)).collect(Collectors.toList()).isEmpty()) {
			throw new MyException("There is no id at all!!!");
		}
		return courseList.stream().filter(x->x.getCname().equals(name)).collect(Collectors.toList());
		
	}
	public void deleteCourseById(int id) throws MyException,SQLException,Exception{
		Connection con=DbUtil.getConnection();
		PreparedStatement pst=con.prepareStatement("delete from course where id=?");
		pst.setInt(1,id);
		pst.executeUpdate();
		int rs=pst.executeUpdate();
		if(rs==0) {
			throw new MyException("There is no id at all!!!");

		}
	}


}
