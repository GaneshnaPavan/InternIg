package service;

import java.sql.SQLException;
import java.util.List;

import dao.CourseDao;
import dao.CourseDaoImpl;
import exception.MyException;
import model.Course;

public class CourseServiceImpl implements CourseService {
	CourseDao courseDao;
	public void addCourse(Course course) throws Exception{
//		Connection con=DbUtil.getConnection();
//		PreparedStatement pst=con.prepareStatement("insert into course values");
//		pst.setInt(1,course.getCid());
//		pst.setString(2,course.getCname());
//		pst.execute();
		courseDao=new CourseDaoImpl();
		courseDao.addCourse(course);
		
		
	}
	public List<Course> listAllCourses() throws Exception{
//		ArrayList<Course> courseList=new ArrayList<>();
//		Connection con=DbUtil.getConnection();
//		Statement st=con.createStatement();
//		ResultSet rs=st.executeQuery("select * from course");
//		while(rs.next()) {
//			Course course=new Course();
//			course.setCid(rs.getInt(1));
//			course.setCname(rs.getString(2));
//			courseList.add(course);
//		}
//		return courseList;
		courseDao=new CourseDaoImpl();
		return courseDao.listAllCourses();
		
	}
	public List<Course> getById(int id) throws MyException,SQLException,Exception{
//		ArrayList<Course> courseList=new ArrayList<>();
//		Connection con=DbUtil.getConnection();
//		Statement st=con.createStatement();
//		ResultSet rs=st.executeQuery("select * from course");
//		while(rs.next()) {
//			Course course=new Course();
//			course.setCid(rs.getInt(1));
//			course.setCname(rs.getString(2));
//			courseList.add(course);
//		}
//		return courseList.stream().filter(x->x.getCid()==id).forEach(x->System.out.println(x));
		courseDao=new CourseDaoImpl();
		
		return courseDao.getById(id);
		
//		
	}
	public List<Course> getByName(String name) throws MyException,SQLException,Exception{
//		ArrayList<Course> courseList=new ArrayList<>();
//		Connection con=DbUtil.getConnection();
//		Statement st=con.createStatement();
//		ResultSet rs=st.executeQuery("select * from course");
//		while(rs.next()) {
//			Course course=new Course();
//			course.setCid(rs.getInt(1));
//			course.setCname(rs.getString(2));
//			courseList.add(course);
//		}
//		return courseList.stream().filter(x->x.getCname().equals(name)).forEach(x->System.out.println(x));
		courseDao=new CourseDaoImpl();
		return courseDao.getByName(name);

	}
	public void deleteCourseById(int id) throws MyException,SQLException,Exception{
		courseDao=new CourseDaoImpl();
		courseDao.deleteCourseById(id);
		
	}


}
