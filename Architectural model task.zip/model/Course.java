package model;

public class Course {
	Integer cid;
	String cname;
	public Course(Integer cid, String cname) {
		super();
		this.cid = cid;
		this.cname = cname;
	}
	public Course() {
		// TODO Auto-generated constructor stub
	}
	public int getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	@Override
	public String toString() {
		return "Course [cid=" + cid + ", cname=" + cname + "]";
	}
	
	

}
