package ui;

import java.util.Scanner;

import model.Course;
import service.CourseService;
import service.CourseServiceImpl;

public class CourseUi {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		CourseService courseService=new CourseServiceImpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the course details");
		
		boolean flag=true;
		while(flag) {
			System.out.println("Enter your choice");
			System.out.println("1.List all the courses");
			System.out.println("2.Add into the course table");
			System.out.println("3.Get the course by id");
			System.out.println("4.Get the course by name");
			System.out.println("5.Delete the course by giving id");
			System.out.println("6.Exit");

			
			int n=sc.nextInt();
			switch(n) {
			case 1:
				System.out.println("=====List of all courses=====");
				courseService.listAllCourses().forEach(x->System.out.println(x));
				break;
			case 2:
				System.out.println("Enter the course details-course id and course name");
				Course course=new Course();
				course.setCid(sc.nextInt());
				sc.nextLine();
				course.setCname(sc.nextLine());
				courseService.addCourse(course);
				break;
			case 3:
				System.out.println("Enter the id");
				int i=sc.nextInt();
				courseService.getById(i).forEach(x->System.out.println(x));
				break;
			case 4:
				System.out.println("Enter the name of the course");
				String nameOfTheCourse=sc.next();
				courseService.getByName(nameOfTheCourse).forEach(x->System.out.println(x));
				break;
			case 5:
				System.out.println("Enter the id for deleting the course");
				int did=sc.nextInt();
				courseService.deleteCourseById(did);
				break;
			case 6:
				System.out.println("Exiting....");
				flag=false;
				break;
			}
			
			}
			
		
		
		
		
	}
	

}
