import React, { useState } from "react";

export default function SignUp() {
    const [value1, setValue1] = useState('');
    const [value2, setValue2] = useState('');
    const [value3, setValue3] = useState('');
    const [value4, setValue4] = useState('');
    const [value5, setValue5] = useState('');
    const [submittedValues, setSubmittedValues] = useState(null);


    const handleChange = event => {
        const { name, value } = event.target;
        if (name === "cusid") {
            setValue1(value)
        }
        else if (name === "name") {
            setValue2(value)
        }
        else if (name === "email") {
            setValue3(value)
        }
        else if (name === "gender") {
            setValue4(value)
        }
        else if (name === "city") {
            setValue5(value)
        }
    };
    const handleSubmit = event => {
        setSubmittedValues(value1);
        setSubmittedValues(value2);
        setSubmittedValues(value3);
        setSubmittedValues(value4);
        setSubmittedValues(value5);



        event.preventDefault();
    }
    return (
        <div>
            <form onSubmit={handleSubmit}>
                <label>Customer Id</label>

                <input type="text" name="cusid" onChange={handleChange} /><br />
                <label>Customer Name</label>

                <input type="text" name="name" onChange={handleChange} /><br />
                <label>Customer Email</label>

                <input type="text" name="email" onChange={handleChange} /><br />
                <label>Customer Gender</label>

                <input type="text" name="gender" onChange={handleChange} /><br />
                <label>Customer City</label>

                <input type="text" name="city" onChange={handleChange} /><br />
                <button type="submit">Sign Up</button>

            </form>

            {submittedValues && (<div>
                <p>{value1}</p>
                <p>{value2}</p>
                <p>{value3}</p>
                <p>{value4}</p>
                <p>{value5}</p>
            </div>
            )}
        </div>
    )
}