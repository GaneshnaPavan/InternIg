import React, { useState } from "react";

export default function Valid() {
    const [value1, setValue1] = React.useState('')
    const [value2, setValue2] = React.useState('')
    const handleChange = event => {
        const { name, value } = event.target;
        if (name === "username") {
            setValue1(value)
        }
        else if (name === "password") {
            setValue2(value)
        }
    };
    const handleSubmit = event => {
        if (value1 === "iguser" && value2 === "password") {
            alert("Valid user")
        }
        else {
            alert("Wrongg-Invalid credentials")
        }

        event.preventDefault();
    };
    return (
        <div>
            <form onSubmit={handleSubmit}>
                <p>UserName</p>
                <input type="text" name="username" value={value1} onChange={handleChange} />
                <br></br>
                <p>Password</p>

                <input type="password" name="password" value={value2} onChange={handleChange} />
                <button type="submit">Check</button>


            </form>
        </div>
    )
}